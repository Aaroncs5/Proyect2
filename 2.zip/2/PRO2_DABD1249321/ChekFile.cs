﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace PRO2_DABD1249321
{
    public class ChekFile
    {
        string[,] DataMatriz;
        string pathfile = @"C:\Users\aaron\source\repos\2\PRO2_DABD1249321\Data\ProyectoB.csv";


        //Verifica si el archivo existe y no vacío
        public bool issetfile()
        {
            if (File.Exists(pathfile) && File.ReadAllText(this.pathfile) != "")
            {
                return true;
            }
            return false;
        }

        //Genera en matriz el achivo CSV
        public string[,] MatrizParaLeer()
        {
            var reader = new StreamReader(File.OpenRead(this.pathfile));
            List<string> lista = new List<string>();
            int contador = 0;
            while (!reader.EndOfStream)
            {
                var linea = reader.ReadLine();
                contador++;
                string[] valores = linea.Split(",");
                foreach (var i in valores)
                {
                    lista.Add(i);
                }
            }
            int n_fila = contador;
            int n_columna = lista.Count / contador;
            int contador2 = 0;
            this.DataMatriz = new string[n_fila, n_columna];
            for (int o = 0; o < n_fila; o++)
            {
                for (int x = 0; x < n_columna; x++)
                {
                    this.DataMatriz[o, x] = lista[contador2];
                    contador2++;
                }
            }
            return this.DataMatriz;
        }
    }
}
